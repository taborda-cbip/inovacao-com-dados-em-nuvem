begin

 DBMS_CLOUD.create_credential (

   credential_name => 'OBJ_STORE_CRED',

   username => '<your username>',

   password => '<your Auth Token>'

 ) ;

end;

/