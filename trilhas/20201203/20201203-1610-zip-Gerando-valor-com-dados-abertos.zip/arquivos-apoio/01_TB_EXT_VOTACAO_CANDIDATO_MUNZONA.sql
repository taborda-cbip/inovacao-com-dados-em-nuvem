BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_VOTACAO_CANDIDATO_MUNZONA',   
      credential_name =>'OBJ_STORE_CRED',   
      file_uri_list =>'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/opendata/o/votacao_candidato_munzona_2016*',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => 'dt_geracao                     VARCHAR2(250) 
                     ,hh_geracao                     VARCHAR2(250)
                     ,nr_ano_eleicao                 VARCHAR2(250)
                     ,cd_tipo_eleicao                VARCHAR2(250)
                     ,nm_tipo_eleicao                VARCHAR2(250)
                     ,nr_turno                       VARCHAR2(250)
                     ,cd_eleicao                     VARCHAR2(250)
                     ,ds_eleicao                     VARCHAR2(250)
                     ,dt_eleicao                     VARCHAR2(250)
                     ,tp_abrangencia                 VARCHAR2(250)
                     ,sg_uf                          VARCHAR2(250)
                     ,sg_ue                          VARCHAR2(250)
                     ,nm_ue                          VARCHAR2(250)
                     ,cd_municipio                   VARCHAR2(250)
                     ,nm_municipio                   VARCHAR2(250)
                     ,nr_zona                        VARCHAR2(250)
                     ,cd_cargo                       VARCHAR2(250)
                     ,ds_cargo                       VARCHAR2(250)
                     ,sq_candidato                   VARCHAR2(250)
                     ,nr_candidato                   VARCHAR2(250)
                     ,nm_candidato                   VARCHAR2(250)
                     ,nm_candidato_urna              VARCHAR2(250)
                     ,nm_candidato_social            VARCHAR2(250)
                     ,cd_situacao_candidatura        VARCHAR2(250)
                     ,ds_situacao_candidatura        VARCHAR2(250)
                     ,cd_situacao_candidato_detalhe  VARCHAR2(250)
                     ,ds_situacao_candidato_detalhe  VARCHAR2(250)
                     ,tp_agremiacao                  VARCHAR2(250)
                     ,nr_partido                     VARCHAR2(250)
                     ,sg_partido                     VARCHAR2(250)
                     ,nm_partido                     VARCHAR2(250)
                     ,sq_coligacao                   VARCHAR2(250)
                     ,nm_coligacao                   VARCHAR2(250)
                     ,ds_coligacao_composicao        VARCHAR2(250)
                     ,cd_situacao_tot_turno          VARCHAR2(250)
                     ,ds_situacao_tot_turno          VARCHAR2(250)
                     ,st_voto_transito               VARCHAR2(250)
                     ,qt_votos_nominais              VARCHAR2(250)
                     ,dt_referencia                  VARCHAR2(250)
                     ,nm_fonte_dados                 VARCHAR2(250)
                     ,nm_arquivo_dados               VARCHAR2(250)');   
   END;
/  