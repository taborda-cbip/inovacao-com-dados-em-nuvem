BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_MUNICIPIO_IBGE',   
      credential_name =>'OBJ_STORE_CRED',   
      file_uri_list =>'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/opendata/o/20201130_municipios.csv',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => ' id_municipio      VARCHAR(250)
					  ,nm_municipio      VARCHAR(250)
					  ,id_microrregiao   VARCHAR(250)
					  ,nm_microrregiao   VARCHAR(250)
					  ,id_mesorregiao    VARCHAR(250)
					  ,nm_mesorregiao    VARCHAR(250)
					  ,id_uf             VARCHAR(250)
					  ,sg_uf             VARCHAR(250)
					  ,nm_uf             VARCHAR(250)
					  ,id_regiao         VARCHAR(250)
					  ,sg_regiao         VARCHAR(250)
					  ,nm_regiao         VARCHAR(250)
					  ,dt_referencia     VARCHAR(250)
					  ,nm_fonte_dados    VARCHAR(250)
					  ,nm_arquivo_dados  VARCHAR(250)');   
   END;
/