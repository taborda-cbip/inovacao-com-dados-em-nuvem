BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_ESPECTRO_POLITICO_PARTIDARIO',   
      credential_name =>'OBJ_STORE_CRED',   
      file_uri_list =>'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/opendata/o/ESPECTRO_POLITICO_PARTIDARIO.csv',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => ' SG_PARTIDO            VARCHAR(250)
					  ,DS_ESPECTRO_POLITICO  VARCHAR(250)');   
   END;
/

