BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_CNPJ_CNAE',   
      credential_name => 'OBJ_STORE_CRED',   
      file_uri_list => 'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/opendata/o/CNAE_*',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => 'tp_registro          VARCHAR2(250)
                     ,in_forma_envio       VARCHAR2(250)
                     ,tp_atualizacao       VARCHAR2(250) 
                     ,nr_cnpj              VARCHAR2(250)
                     ,cd_cnae_secundaria   VARCHAR2(250)
                     ,dt_referencia        VARCHAR2(250)
                     ,nm_fonte_dados       VARCHAR2(250)
                     ,nm_arquivo_dados     VARCHAR2(250)');   
   END;
/  