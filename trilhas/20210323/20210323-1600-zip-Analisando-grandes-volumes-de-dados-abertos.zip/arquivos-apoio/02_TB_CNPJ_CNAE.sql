CREATE TABLE TB_CNPJ_CNAE AS
SELECT
    TP_REGISTRO          AS TP_REGISTRO       
  , IN_FORMA_ENVIO       AS IN_FORMA_ENVIO    
  , TP_ATUALIZACAO       AS TP_ATUALIZACAO    
  , NR_CNPJ              AS NR_CNPJ           
  , CD_CNAE_SECUNDARIA   AS CD_CNAE_SECUNDARIA             
  , TO_DATE(
         DT_REFERENCIA
        ,'YYYY-MM-DD')   AS DT_REFERENCIA                        
  , NM_FONTE_DADOS       AS NM_FONTE_DADOS                       
  , NM_ARQUIVO_DADOS     AS NM_ARQUIVO_DADOS        
    
FROM
    TB_EXT_CNPJ_CNAE
;