BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_CNPJ',   
      credential_name => 'OBJ_STORE_CRED',   
      file_uri_list => 'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/opendata/o/CNPJ_*',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => 'tp_registro                    VARCHAR(250)
                     ,in_forma_envio                 VARCHAR(250)
                     ,tp_atualizacao                 VARCHAR(250)
                     ,nr_cnpj                        VARCHAR(250)
                     ,in_matriz_filial               VARCHAR(250)
                     ,nm_razao_social                VARCHAR(250)
                     ,nm_fantasia                    VARCHAR(250)
                     ,in_situacao_cadastral          VARCHAR(250)
                     ,dt_situacao_cadastral          VARCHAR(250)
                     ,cd_motivo_situacao_cadastral   VARCHAR(250)
                     ,nm_cidade_exterior             VARCHAR(250)
                     ,co_pais                        VARCHAR(250)
                     ,nm_pais                        VARCHAR(250)
                     ,cd_natureza_juridica           VARCHAR(250)
                     ,dt_inicio_atividade            VARCHAR(250)
                     ,cd_cnae_principal              VARCHAR(250)
                     ,tp_logradouro                  VARCHAR(250)
                     ,ds_logradouro                  VARCHAR(250)
                     ,nr_logradouro                  VARCHAR(250)
                     ,ds_logradouro_complemento      VARCHAR(250)
                     ,ds_logradouro_bairro           VARCHAR(250)
                     ,nr_cep                         VARCHAR(250)
                     ,sg_uf                          VARCHAR(250)
                     ,cd_municipio                   VARCHAR(250)
                     ,nm_municipio                   VARCHAR(250)
                     ,nr_telefone_ddd_01             VARCHAR(250)
                     ,nr_telefone_001                VARCHAR(250)
                     ,nr_telefone_ddd_02             VARCHAR(250)
                     ,nr_telefone_002                VARCHAR(250)
                     ,nr_fax_ddd                     VARCHAR(250)
                     ,nr_fax                         VARCHAR(250)
                     ,ds_correio_eletronico          VARCHAR(250)
                     ,cd_qualificacao_responsalvel   VARCHAR(250)
                     ,vl_capital_social              VARCHAR(250)
                     ,cd_porte_empresa               VARCHAR(250)
                     ,cd_opcao_simples               VARCHAR(250)
                     ,dt_opcao_simples_inclusao      VARCHAR(250)
                     ,dt_opcao_simples_exclusao      VARCHAR(250)
                     ,in_existe_opcao_mei            VARCHAR(250)
                     ,ds_situacao_especial           VARCHAR(250)
                     ,dt_situacao_especial           VARCHAR(250)
                     ,dt_referencia                  VARCHAR(250)
                     ,nm_fonte_dados                 VARCHAR(250)
                     ,nm_arquivo_dados               VARCHAR(250)');   
   END;
/  