CREATE TABLE TB_CNPJ AS
SELECT
     TP_REGISTRO                  AS TP_REGISTRO                        
   , IN_FORMA_ENVIO               AS IN_FORMA_ENVIO                     
   , TP_ATUALIZACAO               AS TP_ATUALIZACAO
   , TO_NUMBER(SUBSTR(NR_CNPJ,0,8)) AS ID_CNPJ_8
   , SUBSTR(NR_CNPJ,0,8)          AS NR_CNPJ_8
   , TO_NUMBER(NR_CNPJ)           AS ID_CNPJ_14
   , NR_CNPJ                      AS NR_CNPJ_14                            
   , IN_MATRIZ_FILIAL             AS IN_MATRIZ_FILIAL                   
   , NM_RAZAO_SOCIAL              AS NM_RAZAO_SOCIAL                    
   , NM_FANTASIA                  AS NM_FANTASIA                        
   , IN_SITUACAO_CADASTRAL        AS IN_SITUACAO_CADASTRAL              
   , TO_DATE(
         DT_SITUACAO_CADASTRAL
        ,'YYYY-MM-DD')            AS DT_SITUACAO_CADASTRAL              
   , CD_MOTIVO_SITUACAO_CADASTRAL AS CD_MOTIVO_SITUACAO_CADASTRAL       
   , NM_CIDADE_EXTERIOR           AS NM_CIDADE_EXTERIOR                 
   , CO_PAIS                      AS CO_PAIS                            
   , NM_PAIS                      AS NM_PAIS                            
   , CD_NATUREZA_JURIDICA         AS CD_NATUREZA_JURIDICA               
   , TO_DATE(
         DT_INICIO_ATIVIDADE
        ,'YYYY-MM-DD')            AS DT_INICIO_ATIVIDADE                
   , CD_CNAE_PRINCIPAL            AS CD_CNAE_PRINCIPAL                  
   , TP_LOGRADOURO                AS TP_LOGRADOURO                      
   , DS_LOGRADOURO                AS DS_LOGRADOURO                      
   , NR_LOGRADOURO                AS NR_LOGRADOURO                      
   , DS_LOGRADOURO_COMPLEMENTO    AS DS_LOGRADOURO_COMPLEMENTO          
   , DS_LOGRADOURO_BAIRRO         AS DS_LOGRADOURO_BAIRRO               
   , NR_CEP                       AS NR_CEP                             
   , SG_UF                        AS SG_UF                              
   , CD_MUNICIPIO                 AS CD_MUNICIPIO                       
   , NM_MUNICIPIO                 AS NM_MUNICIPIO                       
   , NR_TELEFONE_DDD_01           AS NR_TELEFONE_DDD_01                   
   , NR_TELEFONE_001              AS NR_TELEFONE_001                      
   , NR_TELEFONE_DDD_02           AS NR_TELEFONE_DDD_02                   
   , NR_TELEFONE_002              AS NR_TELEFONE_002                      
   , NR_FAX_DDD                   AS NR_FAX_DDD                           
   , NR_FAX                       AS NR_FAX                               
   , DS_CORREIO_ELETRONICO        AS DS_CORREIO_ELETRONICO                
   , CD_QUALIFICACAO_RESPONSALVEL AS CD_QUALIFICACAO_RESPONSALVEL         
   , TO_NUMBER(
         VL_CAPITAL_SOCIAL
        ,'999999999999D99'
        ,'NLS_NUMERIC_CHARACTERS=''.,''') AS VL_CAPITAL_SOCIAL                    
   , CD_PORTE_EMPRESA             AS CD_PORTE_EMPRESA                     
   , CD_OPCAO_SIMPLES             AS CD_OPCAO_SIMPLES                     
   , DT_OPCAO_SIMPLES_INCLUSAO          AS DT_OPCAO_SIMPLES_INCLUSAO            
   , DT_OPCAO_SIMPLES_EXCLUSAO           AS DT_OPCAO_SIMPLES_EXCLUSAO            
   , IN_EXISTE_OPCAO_MEI          AS IN_EXISTE_OPCAO_MEI                  
   , DS_SITUACAO_ESPECIAL         AS DS_SITUACAO_ESPECIAL                 
   , DT_SITUACAO_ESPECIAL         AS DT_SITUACAO_ESPECIAL   
   , 1                            AS QT_CNPJ   
   , TO_DATE(
         DT_REFERENCIA
        ,'YYYY-MM-DD')            AS DT_REFERENCIA                        
   , NM_FONTE_DADOS               AS NM_FONTE_DADOS                       
   , NM_ARQUIVO_DADOS             AS NM_ARQUIVO_DADOS        
    
FROM
    TB_EXT_CNPJ
;