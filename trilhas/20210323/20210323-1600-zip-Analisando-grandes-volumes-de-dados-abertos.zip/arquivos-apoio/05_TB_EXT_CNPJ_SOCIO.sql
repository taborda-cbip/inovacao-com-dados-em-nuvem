BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_CNPJ_SOCIO',   
      credential_name => 'OBJ_STORE_CRED',   
      file_uri_list => 'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/opendata/o/SOCIO_*',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => 'tp_registro                  VARCHAR(250)
					 ,in_forma_envio               VARCHAR(250)
					 ,tp_atualizacao               VARCHAR(250)
					 ,nr_cnpj                      VARCHAR(250)
					 ,tp_socio                     VARCHAR(250)
					 ,nm_socio                     VARCHAR(250)
					 ,nr_cpf_cnpj_socio            VARCHAR(250)
					 ,cd_qualificacao_socio        VARCHAR(250)
					 ,pc_capital_social            VARCHAR(250)
					 ,dt_sociedade_inclusao        VARCHAR(250)
					 ,cd_pais_socio                VARCHAR(250)
					 ,nm_pais_socio                VARCHAR(250)
					 ,nr_cpf_representante_legal   VARCHAR(250)
					 ,nm_representante_legal       VARCHAR(250)
					 ,cd_qualificacao_rep_legal    VARCHAR(250)
					 ,dt_referencia                VARCHAR(250)
					 ,nm_fonte_dados               VARCHAR(250)
					 ,nm_arquivo_dados             VARCHAR(250)');   
   END;
/  