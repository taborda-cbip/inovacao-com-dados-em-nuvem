CREATE TABLE TB_CNPJ_SOCIO AS
SELECT
     TP_REGISTRO                  AS TP_REGISTRO                        
   , IN_FORMA_ENVIO               AS IN_FORMA_ENVIO                     
   , TP_ATUALIZACAO               AS TP_ATUALIZACAO
   , TO_NUMBER(SUBSTR(NR_CNPJ,0,8)) AS ID_CNPJ_8
   , SUBSTR(NR_CNPJ,0,8)          AS NR_CNPJ_8
   , TO_NUMBER(NR_CNPJ)           AS ID_CNPJ_14
   , NR_CNPJ                      AS NR_CNPJ_14  
   , TP_SOCIO                     AS TP_SOCIO
   , NM_SOCIO                     AS NM_SOCIO
   , NR_CPF_CNPJ_SOCIO            AS NR_CPF_CNPJ_SOCIO
   , CASE
      WHEN TP_SOCIO = '2'
       THEN SUBSTR(NR_CPF_CNPJ_SOCIO,4,11) || ' - ' || NM_SOCIO
      ELSE NR_CPF_CNPJ_SOCIO || ' - ' || NM_SOCIO
     END                          AS ID_SOCIO
   , CASE
      WHEN TP_SOCIO = '2'
       THEN SUBSTR(NR_CPF_CNPJ_SOCIO,4,11)
      ELSE NULL
     END                          AS NR_CPF_SOCIO
   , CASE
      WHEN TP_SOCIO = '1'
       THEN SUBSTR(NR_CPF_CNPJ_SOCIO,0,8)
      ELSE NULL
     END                          AS NR_CNPJ_8_SOCIO
   , CASE
      WHEN TP_SOCIO = '1'
       THEN NR_CPF_CNPJ_SOCIO
      ELSE NULL
     END                          AS NR_CNPJ_14_SOCIO
   , CD_QUALIFICACAO_SOCIO        AS CD_QUALIFICACAO_SOCIO
   , TO_NUMBER(
         PC_CAPITAL_SOCIAL
        ,'999999999999D99'
        ,'NLS_NUMERIC_CHARACTERS=''.,''') AS PC_CAPITAL_SOCIAL
   , TO_DATE(
         DT_SOCIEDADE_INCLUSAO
        ,'YYYY-MM-DD')            AS DT_SOCIEDADE_INCLUSAO
   , CD_PAIS_SOCIO                AS CD_PAIS_SOCIO
   , NM_PAIS_SOCIO                AS NM_PAIS_SOCIO
   , NR_CPF_REPRESENTANTE_LEGAL   AS NR_CPF_REPRESENTANTE_LEGAL
   , NM_REPRESENTANTE_LEGAL       AS NM_REPRESENTANTE_LEGAL
   , CD_QUALIFICACAO_REP_LEGAL    AS CD_QUALIFICACAO_REP_LEGAL
   , 1                            AS QT_SOCIO
   , TO_DATE(
         DT_REFERENCIA
        ,'YYYY-MM-DD')            AS DT_REFERENCIA
   , NM_FONTE_DADOS               AS NM_FONTE_DADOS
   , NM_ARQUIVO_DADOS             AS NM_ARQUIVO_DADOS    
    
FROM
    TB_EXT_CNPJ_SOCIO
;