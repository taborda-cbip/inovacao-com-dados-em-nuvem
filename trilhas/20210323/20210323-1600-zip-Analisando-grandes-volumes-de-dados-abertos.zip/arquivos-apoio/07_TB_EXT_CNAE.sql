BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_CNAE',   
      credential_name =>'OBJ_STORE_CRED',   
      file_uri_list =>'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/opendata/o/*_cnae.csv',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => ' id_subclasse     VARCHAR2(250)   
                      ,ds_subclasse     VARCHAR2(250)
                      ,id_classe        VARCHAR2(250)
                      ,ds_classe        VARCHAR2(250)
                      ,id_grupo         VARCHAR2(250)
                      ,ds_grupo         VARCHAR2(250)
                      ,id_divisao       VARCHAR2(250)
                      ,ds_divisao       VARCHAR2(250)
                      ,id_secao         VARCHAR2(250)
                      ,ds_secao         VARCHAR2(250)
                      ,dt_referencia    VARCHAR2(250)
                      ,nm_fonte_dados   VARCHAR2(250)
                      ,nm_arquivo_dados VARCHAR2(250)');   
   END;
/  