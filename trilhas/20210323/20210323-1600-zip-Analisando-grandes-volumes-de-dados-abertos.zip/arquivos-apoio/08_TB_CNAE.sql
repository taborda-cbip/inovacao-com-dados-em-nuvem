CREATE TABLE TB_CNAE AS
SELECT 
     ID_SUBCLASSE     as ID_SUBCLASSE       
    ,DS_SUBCLASSE     as DS_SUBCLASSE    
    ,ID_CLASSE        as ID_CLASSE       
    ,DS_CLASSE        as DS_CLASSE       
    ,ID_GRUPO         as ID_GRUPO        
    ,DS_GRUPO         as DS_GRUPO        
    ,ID_DIVISAO       as ID_DIVISAO      
    ,DS_DIVISAO       as DS_DIVISAO      
    ,ID_SECAO         as ID_SECAO        
    ,DS_SECAO         as DS_SECAO        
    ,TO_DATE(
         DT_REFERENCIA
        ,'YYYY-MM-DD') as DT_REFERENCIA   
    ,NM_FONTE_DADOS    as NM_FONTE_DADOS  
    ,NM_ARQUIVO_DADOS  as NM_ARQUIVO_DADOS
    
FROM
    TB_EXT_CNAE
;