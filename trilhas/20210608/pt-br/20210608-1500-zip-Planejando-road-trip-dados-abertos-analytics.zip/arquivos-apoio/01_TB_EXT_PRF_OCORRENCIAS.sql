BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_PRF_OCORRENCIAS',   
      credential_name =>'OBJ_STORE_CRED',   
      file_uri_list =>'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/open-data/o/datatran*',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => 'id_ocorrencia             VARCHAR(250)
                     ,ts_ocorrencia             VARCHAR(250)
                     ,sg_uf                     VARCHAR(250)
                     ,nr_br                     VARCHAR(250)
                     ,nr_km                     VARCHAR(250)
                     ,nm_municipio              VARCHAR(250)
                     ,ds_causa_acidente         VARCHAR(250)
                     ,ds_tipo_acidente          VARCHAR(250)
                     ,ds_classificacao_acidente VARCHAR(250)
                     ,ds_fase_dia               VARCHAR(250)
                     ,ds_sentido_via            VARCHAR(250)
                     ,ds_condicao_metereologica VARCHAR(250)
                     ,ds_tipo_pista             VARCHAR(250)
                     ,ds_tracado_via            VARCHAR(250)
                     ,ds_uso_solo               VARCHAR(250)
                     ,nr_pessoas                VARCHAR(250)
                     ,nr_mortos                 VARCHAR(250)
                     ,nr_feridos_leves          VARCHAR(250)
                     ,nr_feridos_graves         VARCHAR(250)
                     ,nr_ilesos                 VARCHAR(250)
                     ,nr_ignorados              VARCHAR(250)
                     ,nr_feridos                VARCHAR(250)
                     ,nr_veiculos               VARCHAR(250)
                     ,vl_latitude               VARCHAR(250)
                     ,vl_longitude              VARCHAR(250)
                     ,nm_regional               VARCHAR(250)
                     ,nm_delegacia              VARCHAR(250)
                     ,nm_uop                    VARCHAR(250)
                     ,dt_referencia             VARCHAR(250)
                     ,nm_fonte_dados            VARCHAR(250)
                     ,nm_arquivo_dados          VARCHAR(250)');
END;
/ 