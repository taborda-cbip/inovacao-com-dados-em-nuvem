CREATE TABLE TB_PRF_OCORRENCIAS AS
SELECT
     ID_OCORRENCIA                      AS ID_OCORRENCIA            
    ,TO_TIMESTAMP(TS_OCORRENCIA
              ,'YYYY-MM-DD HH24:MI:SS') AS TS_OCORRENCIA            
    ,SG_UF                              AS SG_UF                    
    ,NR_BR                              AS NR_BR                    
    ,NR_KM                              AS NR_KM                    
    ,NM_MUNICIPIO                       AS NM_MUNICIPIO             
    ,DS_CAUSA_ACIDENTE                  AS DS_CAUSA_ACIDENTE        
    ,DS_TIPO_ACIDENTE                   AS DS_TIPO_ACIDENTE         
    ,DS_CLASSIFICACAO_ACIDENTE          AS DS_CLASSIFICACAO_ACIDENTE
    ,DS_FASE_DIA                        AS DS_FASE_DIA              
    ,DS_SENTIDO_VIA                     AS DS_SENTIDO_VIA           
    ,DS_CONDICAO_METEREOLOGICA          AS DS_CONDICAO_METEREOLOGICA
    ,DS_TIPO_PISTA                      AS DS_TIPO_PISTA            
    ,DS_TRACADO_VIA                     AS DS_TRACADO_VIA           
    ,DS_USO_SOLO                        AS DS_USO_SOLO              
    ,TO_NUMBER(NR_PESSOAS
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_PESSOAS               
    ,TO_NUMBER(NR_MORTOS
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_MORTOS                
    ,TO_NUMBER(NR_FERIDOS_LEVES
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_FERIDOS_LEVES         
    ,TO_NUMBER(NR_FERIDOS_GRAVES
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_FERIDOS_GRAVES        
    ,TO_NUMBER(NR_ILESOS
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_ILESOS                
    ,TO_NUMBER(NR_IGNORADOS
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_IGNORADOS             
    ,TO_NUMBER(NR_FERIDOS
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_FERIDOS               
    ,TO_NUMBER(NR_VEICULOS
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS NR_VEICULOS              
    ,TO_NUMBER(VL_LATITUDE
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS VL_LATITUDE              
    ,TO_NUMBER(VL_LONGITUDE
             ,'999999999999D999999999999'
             ,'NLS_NUMERIC_CHARACTERS = ''.,''') AS VL_LONGITUDE             
    ,NM_REGIONAL                        AS NM_REGIONAL              
    ,NM_DELEGACIA                       AS NM_DELEGACIA             
    ,NM_UOP                             AS NM_UOP                   
    ,TO_DATE(DT_REFERENCIA
           ,'YYYY-MM-DD HH24:MI:SS')    AS DT_REFERENCIA            
    ,NM_FONTE_DADOS                     AS NM_FONTE_DADOS           
    ,NM_ARQUIVO_DADOS                   AS NM_ARQUIVO_DADOS  
   
FROM
    TB_EXT_PRF_OCORRENCIAS
;