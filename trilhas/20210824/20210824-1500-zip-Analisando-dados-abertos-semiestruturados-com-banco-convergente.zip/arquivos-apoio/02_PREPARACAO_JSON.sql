/* APAGUE A TABELA CASO NECESSARIO */
-- DROP TABLE tb_municipios;

/* PASSO 01: CRIE TABELA */
CREATE TABLE tb_municipios (
    id  RAW(2000)
   ,doc VARCHAR2(4000)
   ,CHECK (doc IS JSON)
);

/* PASSO 02: POPULE A TABELA */
INSERT INTO tb_municipios VALUES (SYS_GUID(), q'[{"id": 4314902, "nome": "Porto Alegre", "microrregiao": {"id": 43026, "nome": "Porto Alegre", "mesorregiao": {"id": 4305, "nome": "Metropolitana de Porto Alegre", "UF": {"id": 43, "sigla": "RS", "nome": "Rio Grande do Sul", "regiao": {"id": 4, "sigla": "S", "nome": "Sul"}}}}, "regiao-imediata": {"id": 430001, "nome": "Porto Alegre", "regiao-intermediaria": {"id": 4301, "nome": "Porto Alegre", "UF": {"id": 43, "sigla": "RS", "nome": "Rio Grande do Sul", "regiao": {"id": 4, "sigla": "S", "nome": "Sul"}}}}}]');
INSERT INTO tb_municipios VALUES (SYS_GUID(), q'[{"id": 4314407, "nome": "Pelotas", "microrregiao": {"id": 43033, "nome": "Pelotas", "mesorregiao": {"id": 4307, "nome": "Sudeste Rio-grandense", "UF": {"id": 43, "sigla": "RS", "nome": "Rio Grande do Sul", "regiao": {"id": 4, "sigla": "S", "nome": "Sul"}}}}, "regiao-imediata": {"id": 430009, "nome": "Pelotas", "regiao-intermediaria": {"id": 4302, "nome": "Pelotas", "UF": {"id": 43, "sigla": "RS", "nome": "Rio Grande do Sul", "regiao": {"id": 4, "sigla": "S", "nome": "Sul"}}}}}]');
INSERT INTO tb_municipios VALUES (SYS_GUID(), q'[{"id": 4309100, "nome": "Gramado", "microrregiao": {"id": 43024, "nome": "Gramado-Canela", "mesorregiao": {"id": 4305, "nome": "Metropolitana de Porto Alegre", "UF": {"id": 43, "sigla": "RS", "nome": "Rio Grande do Sul", "regiao": {"id": 4, "sigla": "S", "nome": "Sul"}}}}, "regiao-imediata": {"id": 430036, "nome": "Caxias do Sul", "regiao-intermediaria": {"id": 4307, "nome": "Caxias do Sul", "UF": {"id": 43, "sigla": "RS", "nome": "Rio Grande do Sul", "regiao": {"id": 4, "sigla": "S", "nome": "Sul"}}}}}]');

/* PASSO 03: CONSULTE O JSON */
SELECT c.doc FROM tb_municipios c;

/* PASSO 04: USE O DOT NOTATION PARA CONSULTAR CAMPOS ESPECIFICOS DO JSON */
SELECT 
    c.doc.id                                 AS cd_ibge
   ,c.doc.nome                               AS nm_municipio
   ,c.doc.microrregiao.mesorregiao.UF.sigla  AS sg_uf
FROM tb_municipios c;