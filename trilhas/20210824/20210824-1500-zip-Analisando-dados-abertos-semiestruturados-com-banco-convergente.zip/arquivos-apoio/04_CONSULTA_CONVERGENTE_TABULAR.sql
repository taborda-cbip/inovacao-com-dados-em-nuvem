/* CONSULTA 01: RETORNE OS DADOS EM FORMATO TABULAR */
SELECT 
    x.id_nfe            AS id_nfe
   ,x.dt_emissao        AS dt_emissao 
   ,x.nr_cnpj_emit      AS nr_cnpj_emit
   ,te.nm_razao_social  AS nm_razao_social_emit
   ,x.cd_municipio_emit AS cd_municipio_emit
   ,je.nm_municipio     AS nm_municipio_emit
   ,je.sg_uf            AS sg_uf_emit
   ,x.nr_cnpj_dest      AS nr_cnpj_dest
   ,td.nm_razao_social  AS nm_razao_social_dest
   ,x.cd_municipio_emit AS cd_municipio_dest
   ,jd.nm_municipio     AS nm_municipio_dest
   ,jd.sg_uf            AS sg_uf_dest

FROM
    (SELECT 
        inf.* 
     FROM tb_nota_fiscal_eletronica nfe
         ,XMLTABLE('/nfeProc/NFe/infNFe' PASSING nfe.xml 
              COLUMNS
                  id_nfe            VARCHAR2(128)            PATH '@Id'                        
                 ,dt_emissao        TIMESTAMP WITH TIME ZONE PATH 'ide/dhEmi/text()'           
                 ,nr_cnpj_emit      VARCHAR2(14)             PATH 'emit/CNPJ/text()'           
                 ,cd_municipio_emit VARCHAR2(7)              PATH 'emit/enderEmit/cMun/text()' 
                 ,nr_cnpj_dest      VARCHAR2(14)             PATH 'dest/CNPJ/text()'           
                 ,cd_municipio_dest VARCHAR2(7)              PATH 'dest/enderDest/cMun/text()' 
                 ,vl_nf             NUMBER                   PATH 'total/ICMSTot/vNF/text()'   
        ) inf
    ) x

INNER JOIN tb_cnpj te
    ON te.nr_cnpj = x.nr_cnpj_emit

INNER JOIN tb_cnpj td
    ON td.nr_cnpj = x.nr_cnpj_dest

INNER JOIN (
    SELECT 
        c.doc.id                                 AS cd_ibge
       ,c.doc.nome                               AS nm_municipio
       ,c.doc.microrregiao.mesorregiao.UF.sigla  AS sg_uf
    FROM tb_municipios c) je 
ON je.cd_ibge = x.cd_municipio_emit

INNER JOIN (
    SELECT 
        c.doc.id                                 AS cd_ibge
       ,c.doc.nome                               AS nm_municipio
       ,c.doc.microrregiao.mesorregiao.UF.sigla  AS sg_uf
    FROM tb_municipios c) jd 
ON jd.cd_ibge = x.cd_municipio_dest
;
