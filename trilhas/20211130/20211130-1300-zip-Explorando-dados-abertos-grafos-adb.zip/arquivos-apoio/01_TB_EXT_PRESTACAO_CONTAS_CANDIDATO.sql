BEGIN  
   DBMS_CLOUD.CREATE_EXTERNAL_TABLE(   
      table_name => 'TB_EXT_PRESTACAO_CONTAS_CANDIDATO',   
      credential_name =>'OBJ_STORE_CRED',   
      file_uri_list =>'https://objectstorage.sa-saopaulo-1.oraclecloud.com/n/<INSIRA AQUI O NAMESPACE DO SEU BUCKET>/b/<INSIRA AQUI O NOME DO SEU BUCKET>/o/despesas_contratadas_candidatos_*',
      format => json_object(
                          'dateformat' value 'yyyy-mm-dd',
                          'delimiter' value '\t', 
                          'recorddelimiter' value '''\r\n''', 
                          'skipheaders' value '1'
                          ), 
      column_list => ' dt_geracao                 VARCHAR(250)
                      ,hh_geracao                 VARCHAR(250)
                      ,ano_eleicao                VARCHAR(250)
                      ,cd_tipo_eleicao            VARCHAR(250)
                      ,nm_tipo_eleicao            VARCHAR(250)
                      ,cd_eleicao                 VARCHAR(250)
                      ,ds_eleicao                 VARCHAR(250)
                      ,dt_eleicao                 VARCHAR(250)
                      ,st_turno                   VARCHAR(250)
                      ,tp_prestacao_contas        VARCHAR(250)
                      ,dt_prestacao_contas        VARCHAR(250)
                      ,sq_prestador_contas        VARCHAR(250)
                      ,sg_uf                      VARCHAR(250)
                      ,sg_ue                      VARCHAR(250)
                      ,nm_ue                      VARCHAR(250)
                      ,nr_cnpj_prestador_conta    VARCHAR(250)
                      ,cd_cargo                   VARCHAR(250)
                      ,ds_cargo                   VARCHAR(250)
                      ,sq_candidato               VARCHAR(250)
                      ,nr_candidato               VARCHAR(250)
                      ,nm_candidato               VARCHAR(250)
                      ,nr_cpf_candidato           VARCHAR(250)
                      ,nr_cpf_vice_candidato      VARCHAR(250)
                      ,nr_partido                 VARCHAR(250)
                      ,sg_partido                 VARCHAR(250)
                      ,nm_partido                 VARCHAR(250)
                      ,cd_tipo_fornecedor         VARCHAR(250)
                      ,ds_tipo_fornecedor         VARCHAR(250)
                      ,cd_cnae_fornecedor         VARCHAR(250)
                      ,ds_cnae_fornecedor         VARCHAR(250)
                      ,nr_cpf_cnpj_fornecedor     VARCHAR(250)
                      ,nm_fornecedor              VARCHAR(250)
                      ,nm_fornecedor_rfb          VARCHAR(250)
                      ,cd_esfera_part_fornecedor  VARCHAR(250)
                      ,ds_esfera_part_fornecedor  VARCHAR(250)
                      ,sg_uf_fornecedor           VARCHAR(250)
                      ,cd_municipio_fornecedor    VARCHAR(250)
                      ,nm_municipio_fornecedor    VARCHAR(250)
                      ,sq_candidato_fornecedor    VARCHAR(250)
                      ,nr_candidato_fornecedor    VARCHAR(250)
                      ,cd_cargo_fornecedor        VARCHAR(250)
                      ,ds_cargo_fornecedor        VARCHAR(250)
                      ,nr_partido_fornecedor      VARCHAR(250)
                      ,sg_partido_fornecedor      VARCHAR(250)
                      ,nm_partido_fornecedor      VARCHAR(250)
                      ,ds_tipo_documento          VARCHAR(250)
                      ,nr_documento               VARCHAR(250)
                      ,cd_origem_despesa          VARCHAR(250)
                      ,ds_origem_despesa          VARCHAR(250)
                      ,sq_despesa                 VARCHAR(250)
                      ,dt_despesa                 VARCHAR(250)
                      ,ds_despesa                 VARCHAR(250)
                      ,vr_despesa_contratada      VARCHAR(250)
                      ,dt_referencia              VARCHAR(250)
                      ,nm_fonte_dados             VARCHAR(250)
                      ,nm_arquivo_dados           VARCHAR(250)
                     ');
END;
/ 