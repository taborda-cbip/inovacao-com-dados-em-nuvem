-- DROP TABLE TB_PRESTACAO_CONTAS_CANDIDATO;

CREATE TABLE TB_PRESTACAO_CONTAS_CANDIDATO AS
SELECT
    TO_TIMESTAMP(
        DT_GERACAO || ' ' || HH_GERACAO
       ,'YYYY-MM-DD HH24:MI:SS')  AS TS_GERACAO                             
   ,ANO_ELEICAO                   AS ANO_ELEICAO              
   ,CD_TIPO_ELEICAO               AS CD_TIPO_ELEICAO          
   ,NM_TIPO_ELEICAO               AS NM_TIPO_ELEICAO          
   ,CD_ELEICAO                    AS CD_ELEICAO               
   ,DS_ELEICAO                    AS DS_ELEICAO               
   ,TO_DATE(
       DT_ELEICAO
      ,'YYYY-MM-DD HH24:MI:SS')   AS DT_ELEICAO               
   ,ST_TURNO                      AS ST_TURNO                 	
   ,TP_PRESTACAO_CONTAS           AS TP_PRESTACAO_CONTAS      
   ,TO_DATE(
       DT_PRESTACAO_CONTAS
      ,'YYYY-MM-DD HH24:MI:SS')   AS DT_PRESTACAO_CONTAS      
   ,SQ_PRESTADOR_CONTAS           AS SQ_PRESTADOR_CONTAS      
   ,SG_UF                         AS SG_UF                    
   ,SG_UE                         AS SG_UE                    
   ,NM_UE                         AS NM_UE                    
   ,NR_CNPJ_PRESTADOR_CONTA       AS NR_CNPJ_PRESTADOR_CONTA 
   ,CD_CARGO                      AS CD_CARGO                 
   ,DS_CARGO                      AS DS_CARGO
   ,TO_NUMBER(SQ_CANDIDATO)       AS ID_CANDIDATO             
   ,SQ_CANDIDATO                  AS SQ_CANDIDATO             
   ,NR_CANDIDATO                  AS NR_CANDIDATO             
   ,NM_CANDIDATO                  AS NM_CANDIDATO             
   ,NR_CPF_CANDIDATO              AS NR_CPF_CANDIDATO         
   ,NR_CPF_VICE_CANDIDATO         AS NR_CPF_VICE_CANDIDATO
   ,TO_NUMBER(NR_PARTIDO)         AS ID_PARTIDO    
   ,NR_PARTIDO                    AS NR_PARTIDO               
   ,SG_PARTIDO                    AS SG_PARTIDO               
   ,NM_PARTIDO                    AS NM_PARTIDO               
   ,CD_TIPO_FORNECEDOR            AS CD_TIPO_FORNECEDOR       
   ,DS_TIPO_FORNECEDOR            AS DS_TIPO_FORNECEDOR
   ,TO_NUMBER(CD_CNAE_FORNECEDOR) AS ID_CNAE_FORNECEDOR       
   ,CD_CNAE_FORNECEDOR            AS CD_CNAE_FORNECEDOR       
   ,DS_CNAE_FORNECEDOR            AS DS_CNAE_FORNECEDOR       
   ,CASE
      WHEN NR_CPF_CNPJ_FORNECEDOR = '-1' 
	    THEN -1
      WHEN CD_TIPO_FORNECEDOR = '1'
        THEN TO_NUMBER('1' || SUBSTR(NR_CPF_CNPJ_FORNECEDOR,1,8))
      ELSE TO_NUMBER('1' || NR_CPF_CNPJ_FORNECEDOR)
    END                           AS ID_CPF_CNPJ_FORNECEDOR
   ,NR_CPF_CNPJ_FORNECEDOR        AS NR_CPF_CNPJ_FORNECEDOR   
   ,NM_FORNECEDOR                 AS NM_FORNECEDOR            
   ,NM_FORNECEDOR_RFB             AS NM_FORNECEDOR_RFB        
   ,CD_ESFERA_PART_FORNECEDOR     AS CD_ESFERA_PART_FORNECEDOR
   ,DS_ESFERA_PART_FORNECEDOR     AS DS_ESFERA_PART_FORNECEDOR
   ,SG_UF_FORNECEDOR              AS SG_UF_FORNECEDOR         
   ,CD_MUNICIPIO_FORNECEDOR       AS CD_MUNICIPIO_FORNECEDOR  
   ,NM_MUNICIPIO_FORNECEDOR       AS NM_MUNICIPIO_FORNECEDOR  
   ,SQ_CANDIDATO_FORNECEDOR       AS SQ_CANDIDATO_FORNECEDOR  
   ,NR_CANDIDATO_FORNECEDOR       AS NR_CANDIDATO_FORNECEDOR  
   ,CD_CARGO_FORNECEDOR           AS CD_CARGO_FORNECEDOR      
   ,DS_CARGO_FORNECEDOR           AS DS_CARGO_FORNECEDOR      
   ,NR_PARTIDO_FORNECEDOR         AS NR_PARTIDO_FORNECEDOR    
   ,SG_PARTIDO_FORNECEDOR         AS SG_PARTIDO_FORNECEDOR    
   ,NM_PARTIDO_FORNECEDOR         AS NM_PARTIDO_FORNECEDOR    
   ,DS_TIPO_DOCUMENTO             AS DS_TIPO_DOCUMENTO        
   ,NR_DOCUMENTO                  AS NR_DOCUMENTO
   ,TO_NUMBER(CD_ORIGEM_DESPESA)  AS ID_ORIGEM_DESPESA             
   ,CD_ORIGEM_DESPESA             AS CD_ORIGEM_DESPESA        
   ,DS_ORIGEM_DESPESA             AS DS_ORIGEM_DESPESA        
   ,SQ_DESPESA                    AS SQ_DESPESA               
   ,TO_DATE(
       DT_DESPESA
      ,'YYYY-MM-DD HH24:MI:SS')   AS DT_DESPESA               
   ,DS_DESPESA                    AS DS_DESPESA               
   ,TO_NUMBER(VR_DESPESA_CONTRATADA) AS VR_DESPESA_CONTRATADA
   ,1                                AS QT_DESPESA_CONTRATADA    
   ,TO_DATE(
       DT_REFERENCIA
      ,'YYYY-MM-DD HH24:MI:SS')      AS DT_REFERENCIA            
   ,NM_FONTE_DADOS                   AS NM_FONTE_DADOS           
   ,NM_ARQUIVO_DADOS                 AS NM_ARQUIVO_DADOS

FROM
    TB_EXT_PRESTACAO_CONTAS_CANDIDATO

;